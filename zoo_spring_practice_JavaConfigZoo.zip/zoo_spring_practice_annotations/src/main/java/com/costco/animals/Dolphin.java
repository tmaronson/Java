package com.costco.animals;

import org.springframework.stereotype.Component;

@Component
public class Dolphin implements Animal {

	public void speak() {
		// TODO Auto-generated method stub
		System.out.println("sonar clickies");
	}

	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("mmmm fishies taste good");
	}

	public void move() {
		// TODO Auto-generated method stub
		System.out.println("commencing elegant swimming");
	}

	@Override
	public String toString() {
		return super.toString();
	}
	
	

}
