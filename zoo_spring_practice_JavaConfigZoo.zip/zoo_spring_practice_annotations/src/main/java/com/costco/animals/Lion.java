package com.costco.animals;

import org.springframework.stereotype.Component;

@Component("lion")
public class Lion implements Animal {

	public void speak() {
		System.out.println("hear me roar");
	}

	public void eat() {
		System.out.println("whatever I want");

	}

	public void move() {
		System.out.println("prancing but stumbles against Packers");

	}
	
	@Override
	public String toString() {
		return super.toString();
	}

}
