package com.costco.animals;

public interface Animal {
	public void speak();
	public void eat();
	public void move();
}
