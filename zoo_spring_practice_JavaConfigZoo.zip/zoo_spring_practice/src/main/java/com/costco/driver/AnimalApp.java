package com.costco.driver;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.costco.animals.Animal;
import com.costco.zoo.Zoo;

public class AnimalApp {

	public static void main(String[] args) {

		ApplicationContext ctx = 
				new ClassPathXmlApplicationContext("beans.xml");
		Zoo zoo = (Zoo) ctx.getBean("zoo");
		for(Animal animal : zoo.getAnimals()) {
			animal.eat();
			animal.move();
			animal.speak();
		}
	}

}
