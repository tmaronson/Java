package com.costco.zoo;

import java.util.List;

import com.costco.animals.Animal;

public class Zoo {
	private Animal animal; // kept this property after List added
	private List<Animal> animals;

	public Animal getAnimal() {
		return animal;
	}

	public void setAnimal(Animal animal) {
		this.animal = animal;
	}

	

	public List<Animal> getAnimals() {
		return animals;
	}

	public void setAnimals(List<Animal> animals) {
		this.animals = animals;
	}
	
	@Override
	public String toString() {
		return "Zoo [animal=" + animal + "]";
	}
	
}
