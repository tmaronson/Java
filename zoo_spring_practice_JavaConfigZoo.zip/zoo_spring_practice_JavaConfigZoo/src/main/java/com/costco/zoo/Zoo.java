package com.costco.zoo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import com.costco.animals.Animal;


public class Zoo {
	//private Animal animal; // kept this property after List added
	private List<Animal> animals;

	
	public List<Animal> getAnimals() {
		return animals;
	}

	//@Autowired
	public void setAnimals(List<Animal> animals) {
		this.animals = animals;
	}
	
	@Override
	public String toString() {
		return "Zoo [animal=" + animals + "]";
	}
	
}
