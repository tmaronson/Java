package com.costco.driver;

import java.util.Arrays;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.costco.animals.Animal;
import com.costco.animals.Dolphin;
import com.costco.animals.Lion;
import com.costco.zoo.Zoo;

@Configuration
public class ZooConfig {

	@Bean
	public Zoo zoo() {
		return new Zoo();
	}
	
	@Bean
	public List<Animal> list() {
		return Arrays.asList(new Lion(), new Dolphin());
	}
	
	/*@Bean
	public Lion lion() {
		return new Lion();
	}*/
	
	/*
	 * @Bean
	 
	public Dolphin dolphin() {
		return new Dolphin();
	}
	*/
}
